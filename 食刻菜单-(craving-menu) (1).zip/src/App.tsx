/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Utensils, 
  Link as LinkIcon, 
  MessageSquare, 
  Trash2, 
  Sparkles, 
  Calendar, 
  Clock,
  ChevronRight,
  ChefHat,
  ShoppingBag,
  Download,
  ArrowLeft,
  Loader2,
  Image as ImageIcon,
  Camera,
  X,
  Leaf,
  Ban,
  Users
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import ReactMarkdown from 'react-markdown';
import { Craving, MenuPlan, AtmosphereType, ATMOSPHERES, MenuCustomization } from './types';
import { extractFoodFromInput, extractFoodFromImage, generateMenuPlan, generateDishImage, regenerateRecipes } from './services/gemini';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const TEST_DATA: Craving[] = [
    { id: 't1', content: '香蕉可可布朗尼', type: 'text', timestamp: Date.now(), extractedFood: '香蕉可可布朗尼', priority: 2 },
    { id: 't2', content: '香椰咖喱罗氏虾', type: 'text', timestamp: Date.now() - 1000, extractedFood: '香椰咖喱罗氏虾', priority: 3 },
    { id: 't3', content: '西葫芦拌蟹柳', type: 'text', timestamp: Date.now() - 2000, extractedFood: '西葫芦拌蟹柳', priority: 1 },
    { id: 't4', content: '罗宋汤', type: 'text', timestamp: Date.now() - 3000, extractedFood: '罗宋汤', priority: 2 },
    { id: 't5', content: '泰式冬阴功汤', type: 'text', timestamp: Date.now() - 4000, extractedFood: '泰式冬阴功汤', priority: 3 },
    { id: 't6', content: '日式照烧鸡腿排', type: 'text', timestamp: Date.now() - 5000, extractedFood: '日式照烧鸡腿排', priority: 2 },
    { id: 't7', content: '法式红酒炖牛肉', type: 'text', timestamp: Date.now() - 6000, extractedFood: '法式红酒炖牛肉', priority: 3 },
    { id: 't8', content: '意大利松露奶油面', type: 'text', timestamp: Date.now() - 7000, extractedFood: '意大利松露奶油面', priority: 1 },
    { id: 't9', content: '韩式泡菜芝士锅', type: 'text', timestamp: Date.now() - 8000, extractedFood: '韩式泡菜芝士锅', priority: 2 },
    { id: 't10', content: '川味口水鸡', type: 'text', timestamp: Date.now() - 9000, extractedFood: '川味口水鸡', priority: 3 },
    { id: 't11', content: '粤式避风塘炒蟹', type: 'text', timestamp: Date.now() - 10000, extractedFood: '粤式避风塘炒蟹', priority: 2 },
    { id: 't12', content: '墨西哥牛肉塔可', type: 'text', timestamp: Date.now() - 11000, extractedFood: '墨西哥牛肉塔可', priority: 1 },
    { id: 't13', content: '印度黄油鸡咖喱', type: 'text', timestamp: Date.now() - 12000, extractedFood: '印度黄油鸡咖喱', priority: 2 },
    { id: 't14', content: '希腊大虾沙拉', type: 'text', timestamp: Date.now() - 13000, extractedFood: '希腊大虾沙拉', priority: 1 },
  ];

  const [cravings, setCravings] = useState<Craving[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [view, setView] = useState<'home' | 'generate' | 'result' | 'prep' | 'recipes'>('home');
  const [selectedAtmosphere, setSelectedAtmosphere] = useState<AtmosphereType>('CHINESE_FEAST');
  const [selectedDate, setSelectedDate] = useState(() => {
    const d = new Date();
    // Default to next Saturday if today isn't weekend, or just today
    return d.toISOString().split('T')[0];
  });
  const [selectedTime, setSelectedTime] = useState('19:00');
  const [generatedMenu, setGeneratedMenu] = useState<MenuPlan | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [dinerCount, setDinerCount] = useState(2);
  const [dietaryRestrictions, setDietaryRestrictions] = useState('');
  const [isDieting, setIsDieting] = useState(false);
  const [skillLevel, setSkillLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [isRegeneratingRecipes, setIsRegeneratingRecipes] = useState(false);
  const [menuStyle, setMenuStyle] = useState<'INS' | 'HOTEL' | 'HOME'>('INS');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedPriority, setSelectedPriority] = useState<1 | 2 | 3>(1);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const PRIORITY_LABELS = {
    1: { label: '想吃', emoji: '😋', color: 'text-blue-500', bg: 'bg-blue-50' },
    2: { label: '很想吃', emoji: '🔥', color: 'text-orange-500', bg: 'bg-orange-50' },
    3: { label: '馋疯了', emoji: '🚀', color: 'text-red-500', bg: 'bg-red-50' }
  };

  // Load cravings from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('cravings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0) {
          setCravings(parsed);
        } else {
          setCravings(TEST_DATA);
        }
      } catch (e) {
        console.error('Failed to parse cravings', e);
        setCravings(TEST_DATA);
      }
    } else {
      setCravings(TEST_DATA);
    }
  }, []);

  // Save cravings to localStorage
  useEffect(() => {
    localStorage.setItem('cravings', JSON.stringify(cravings));
  }, [cravings]);

  const handleSaveEdit = (id: string) => {
    setCravings(prev => prev.map(c => c.id === id ? { ...c, extractedFood: editValue } : c));
    setEditingId(null);
  };

  const startEditing = (craving: Craving) => {
    setEditingId(craving.id);
    setEditValue(craving.extractedFood || '');
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddCraving = async () => {
    if (!inputValue.trim() && !selectedImage) return;

    const currentInput = inputValue;
    const currentImage = selectedImage;
    setInputValue('');
    setSelectedImage(null);
    
    const urlRegex = /https?:\/\/[^\s]+/;
    const hasUrl = !currentImage && urlRegex.test(currentInput);
    
    const tempId = Date.now().toString();
    const newCraving: Craving = {
      id: tempId,
      content: currentInput,
      type: currentImage ? 'image' : (hasUrl ? 'link' : 'text'),
      timestamp: Date.now(),
      extractedFood: undefined,
      image: currentImage || undefined,
      priority: selectedPriority
    };

    setCravings(prev => [newCraving, ...prev]);
    setSelectedPriority(1); // Reset priority after adding

    try {
      let extractedFood;
      if (currentImage) {
        extractedFood = await extractFoodFromImage(currentImage, currentInput);
      } else {
        extractedFood = await extractFoodFromInput(currentInput);
      }
      setCravings(prev => prev.map(c => c.id === tempId ? { ...c, extractedFood } : c));
    } catch (error) {
      setCravings(prev => prev.map(c => c.id === tempId ? { ...c, extractedFood: '未知' } : c));
    }
  };

  const handleSkillLevelChange = async (level: 'beginner' | 'intermediate' | 'advanced') => {
    if (level === skillLevel || !generatedMenu) return;
    
    setSkillLevel(level);
    setIsRegeneratingRecipes(true);
    try {
      const newRecipes = await regenerateRecipes(generatedMenu, level);
      
      // Set recipes without images first
      setGeneratedMenu({ ...generatedMenu, recipes: newRecipes });

      // Fetch images for new recipes in background
      const recipesWithImages = await Promise.all(newRecipes.map(async (recipe) => {
        const stepsWithImages = await Promise.all(recipe.steps.map(async (step) => {
          try {
            const imageUrl = await generateDishImage(`${recipe.name} ${step.description}`);
            return { ...step, imageUrl };
          } catch (e: any) {
            return step;
          }
        }));
        return { ...recipe, steps: stepsWithImages };
      }));

      setGeneratedMenu({ ...generatedMenu, recipes: recipesWithImages });
    } catch (error) {
      console.error("Failed to regenerate recipes", error);
    } finally {
      setIsRegeneratingRecipes(false);
    }
  };

  const removeCraving = (id: string) => {
    setCravings(prev => prev.filter(c => c.id !== id));
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const customization: MenuCustomization = {
        dinerCount,
        dietaryRestrictions,
        isDieting,
      };
      const mealTimeStr = `${selectedDate} ${selectedTime}`;
      const menu = await generateMenuPlan(cravings, selectedAtmosphere, mealTimeStr, customization, skillLevel);
      
      // Set initial menu without images first
      setGeneratedMenu(menu);
      setView('result');

      // Generate images in background
      const dishesWithImages = await Promise.all(menu.dishes.map(async (dish) => {
        try {
          const imageUrl = await generateDishImage(dish.imagePrompt);
          return { ...dish, imageUrl };
        } catch (e: any) {
          return { ...dish, imageUrl: `https://picsum.photos/seed/${encodeURIComponent(dish.name)}/800/800` };
        }
      }));

      const recipesWithImages = await Promise.all(menu.recipes.map(async (recipe) => {
        const stepsWithImages = await Promise.all(recipe.steps.map(async (step) => {
          try {
            const imageUrl = await generateDishImage(`${recipe.name} ${step.description}`);
            return { ...step, imageUrl };
          } catch (e: any) {
            return step;
          }
        }));
        return { ...recipe, steps: stepsWithImages };
      }));

      setGeneratedMenu({ ...menu, dishes: dishesWithImages, recipes: recipesWithImages });
    } catch (error) {
      alert('生成菜单失败，请稍后再试');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-[#FDFCFB] shadow-xl relative overflow-hidden flex flex-col border-x border-[#F0F0E8]">
      {/* Decorative background elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[20%] bg-[#5A5A40]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-5%] right-[-5%] w-[50%] h-[25%] bg-amber-100/30 rounded-full blur-3xl pointer-events-none" />
      
      {/* Header */}
      <header className="p-6 pb-2 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-[#5A5A40] rounded-full flex items-center justify-center text-white">
            <Utensils size={20} />
          </div>
          <h1 className="text-2xl font-bold serif tracking-tight">食刻菜单 ✨</h1>
        </div>
        {view !== 'home' && (
          <button 
            onClick={() => {
              if (view === 'prep' || view === 'recipes') setView('result');
              else setView('home');
            }}
            className="p-2 hover:bg-black/5 rounded-full transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
        )}
      </header>

      <main className="flex-1 overflow-y-auto p-6 pt-2 pb-24">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* Input Section */}
              <section className="space-y-4">
                <div className="bg-white p-4 rounded-3xl shadow-sm border border-[#E5E5E0] space-y-3">
                  <div className="flex items-center gap-2 text-xs font-medium text-[#8E8E80] uppercase tracking-widest">
                    <Sparkles size={12} className="text-amber-400" />
                    <span>捕捉今日味蕾灵感 🥘</span>
                  </div>
                  <textarea
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="想吃什么？直接输入、粘贴链接或上传图片... 📸"
                    className="w-full h-24 resize-none bg-transparent focus:outline-none text-lg leading-relaxed placeholder:text-[#C0C0B0]"
                  />
                  
                  {selectedImage && (
                    <div className="relative inline-block">
                      <img 
                        src={selectedImage} 
                        alt="Selected" 
                        className="h-20 w-20 object-cover rounded-xl border border-[#E5E5E0]"
                        referrerPolicy="no-referrer"
                      />
                      <button 
                        onClick={() => setSelectedImage(null)}
                        className="absolute -top-2 -right-2 bg-white rounded-full shadow-md p-1 border border-[#E5E5E0]"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  )}

                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1">
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="p-2 text-[#8E8E80] hover:bg-[#F5F5F0] rounded-full transition-colors"
                          title="上传图片"
                        >
                          <ImageIcon size={20} />
                        </button>
                      </div>
                      <input 
                        type="file"
                        ref={fileInputRef}
                        onChange={handleImageSelect}
                        accept="image/*"
                        className="hidden"
                      />
                    </div>
                      
                      <div className="flex bg-[#F5F5F0] p-1 rounded-full border border-[#E5E5E0]">
                        {(Object.keys(PRIORITY_LABELS) as unknown as (1 | 2 | 3)[]).map((p) => (
                          <button
                            key={p}
                            onClick={() => setSelectedPriority(p)}
                            className={cn(
                              "px-3 py-1.5 rounded-full text-[10px] font-bold transition-all duration-300",
                              selectedPriority === p 
                                ? `${PRIORITY_LABELS[p].bg} ${PRIORITY_LABELS[p].color} shadow-sm scale-110 z-10` 
                                : "text-[#C0C0B0] hover:text-[#8E8E80]"
                            )}
                          >
                            <span className="mr-1">{PRIORITY_LABELS[p].emoji}</span>
                            {PRIORITY_LABELS[p].label}
                          </button>
                        ))}
                      </div>
                    </div>
                    <button
                      onClick={handleAddCraving}
                      disabled={isProcessing || (!inputValue.trim() && !selectedImage)}
                      className={cn(
                        "px-6 py-2 rounded-full bg-[#5A5A40] text-white font-medium flex items-center gap-2 transition-all active:scale-95",
                        (isProcessing || (!inputValue.trim() && !selectedImage)) && "opacity-50 grayscale"
                      )}
                    >
                      {isProcessing ? <Loader2 className="animate-spin" size={18} /> : <Plus size={18} />}
                      <span>收藏</span>
                    </button>
                  </div>
              </section>

              {/* Cravings List */}
              <section className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-bold serif">我的点菜清单 📝 ({cravings.length})</h2>
                  {cravings.length > 0 && (
                    <button 
                      onClick={() => setView('generate')}
                      className="text-[#5A5A40] text-sm font-medium flex items-center gap-1"
                    >
                      <span>去整合菜单 👩‍🍳</span>
                      <ChevronRight size={16} />
                    </button>
                  )}
                </div>

                {cravings.length === 0 ? (
                  <div className="py-12 text-center space-y-3 opacity-40">
                    <div className="w-16 h-16 bg-[#E5E5E0] rounded-full flex items-center justify-center mx-auto">
                      <ChefHat size={32} />
                    </div>
                    <p className="text-sm">空空如也，快去发现美味吧 🥗</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {cravings.map((craving) => (
                      <motion.div
                        layout
                        key={craving.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-white p-4 rounded-2xl border border-[#F0F0E8] flex justify-between items-start gap-4 group"
                      >
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {craving.type === 'link' ? (
                                <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center">
                                  <LinkIcon size={12} className="text-blue-500" />
                                </div>
                              ) : craving.type === 'image' ? (
                                <div className="w-6 h-6 rounded-full bg-emerald-50 flex items-center justify-center">
                                  <ImageIcon size={12} className="text-emerald-500" />
                                </div>
                              ) : (
                                <div className="w-6 h-6 rounded-full bg-amber-50 flex items-center justify-center">
                                  <MessageSquare size={12} className="text-amber-500" />
                                </div>
                              )}
                              <span className="text-[10px] font-medium text-[#8E8E80] uppercase tracking-wider">
                                {new Date(craving.timestamp).toLocaleDateString()}
                              </span>
                            </div>
                            <div className={cn(
                              "px-2 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5 shadow-sm",
                              (PRIORITY_LABELS[craving.priority] || PRIORITY_LABELS[1]).bg,
                              (PRIORITY_LABELS[craving.priority] || PRIORITY_LABELS[1]).color
                            )}>
                              <span>{(PRIORITY_LABELS[craving.priority] || PRIORITY_LABELS[1]).emoji}</span>
                              <span>{(PRIORITY_LABELS[craving.priority] || PRIORITY_LABELS[1]).label}</span>
                            </div>
                          </div>
                          
                          {craving.image && (
                            <img 
                              src={craving.image} 
                              alt="Craving" 
                              className="w-full h-32 object-cover rounded-xl border border-[#F0F0E8]"
                              referrerPolicy="no-referrer"
                            />
                          )}
                          
                          {editingId === craving.id ? (
                            <div className="flex gap-2">
                              <input
                                autoFocus
                                value={editValue}
                                onChange={(e) => setEditValue(e.target.value)}
                                onBlur={() => handleSaveEdit(craving.id)}
                                onKeyDown={(e) => e.key === 'Enter' && handleSaveEdit(craving.id)}
                                className="flex-1 bg-[#F5F5F0] border-b-2 border-[#5A5A40] px-2 py-1 text-lg font-bold serif outline-none"
                              />
                            </div>
                          ) : craving.extractedFood === undefined ? (
                            <div className="flex items-center gap-2 text-[#C0C0B0]">
                              <Loader2 size={16} className="animate-spin" />
                              <span className="text-sm italic">正在识别美味...</span>
                            </div>
                          ) : craving.extractedFood && craving.extractedFood !== '未知' ? (
                            <div className="space-y-1 group/item">
                              <div className="flex items-center gap-2">
                                <h3 className="font-bold text-[#5A5A40] text-lg serif leading-tight">
                                  {craving.extractedFood}
                                </h3>
                                <button 
                                  onClick={() => startEditing(craving)}
                                  className="opacity-0 group-hover/item:opacity-100 p-1 text-[#C0C0B0] hover:text-[#5A5A40] transition-all"
                                >
                                  <Plus size={12} className="rotate-45" />
                                </button>
                              </div>
                              <p className="text-sm text-[#8E8E80] line-clamp-1 italic">
                                "{craving.content}"
                              </p>
                            </div>
                          ) : (
                            <div className="space-y-1 group/item">
                              <div className="flex items-center gap-2">
                                <h3 className="font-bold text-[#C0C0B0] text-sm italic leading-tight">
                                  未识别出菜名，点击编辑
                                </h3>
                                <button 
                                  onClick={() => startEditing(craving)}
                                  className="opacity-0 group-hover/item:opacity-100 p-1 text-[#C0C0B0] hover:text-[#5A5A40] transition-all"
                                >
                                  <Plus size={12} className="rotate-45" />
                                </button>
                              </div>
                              <p className="text-[#2D2D2D] line-clamp-2 text-sm opacity-60">{craving.content}</p>
                            </div>
                          )}
                        </div>
                        <button 
                          onClick={() => removeCraving(craving.id)}
                          className="p-2 text-[#C0C0B0] hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </motion.div>
                    ))}
                  </div>
                )}
              </section>
            </motion.div>
          )}

          {view === 'generate' && (
            <motion.div
              key="generate"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <h2 className="text-2xl font-bold serif">定制周末盛宴 🥂</h2>
                <p className="text-[#8E8E80] text-sm">我们将从您的收藏中挑选灵感，为您打造专属菜单。✨</p>
              </div>

              <section className="space-y-4">
                <label className="text-sm font-bold uppercase tracking-widest text-[#8E8E80]">选择氛围 🎭</label>
                <div className="grid gap-3">
                  {(Object.keys(ATMOSPHERES) as AtmosphereType[]).map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedAtmosphere(type)}
                      className={cn(
                        "p-4 rounded-2xl border text-left transition-all flex items-center gap-4",
                        selectedAtmosphere === type 
                          ? "bg-[#5A5A40] border-[#5A5A40] text-white shadow-lg scale-[1.02]" 
                          : "bg-white border-[#F0F0E8] text-[#2D2D2D] hover:border-[#5A5A40]/30"
                      )}
                    >
                      <span className="text-2xl">{ATMOSPHERES[type].emoji}</span>
                      <div className="flex-1">
                        <div className="font-bold">{ATMOSPHERES[type].label}</div>
                        <div className={cn("text-xs", selectedAtmosphere === type ? "text-white/70" : "text-[#8E8E80]")}>
                          {ATMOSPHERES[type].description}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </section>

              <section className="space-y-4">
                <label className="text-sm font-bold uppercase tracking-widest text-[#8E8E80]">用餐人数 👥</label>
                <div className="flex items-center gap-4 bg-white p-2 rounded-2xl border border-[#F0F0E8]">
                  {[1, 2, 4, 6, 8].map(num => (
                    <button
                      key={num}
                      onClick={() => setDinerCount(num)}
                      className={cn(
                        "flex-1 py-2 rounded-xl text-sm font-bold transition-all",
                        dinerCount === num ? "bg-[#5A5A40] text-white shadow-md" : "text-[#8E8E80] hover:bg-[#F5F5F0]"
                      )}
                    >
                      {num}人
                    </button>
                  ))}
                </div>
              </section>

              <section className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-bold uppercase tracking-widest text-[#8E8E80]">定制化偏好 🎨</label>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-[#F0F0E8] space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center text-green-600">
                        <Leaf size={16} />
                      </div>
                      <span className="text-sm font-medium">正在减肥/健身</span>
                    </div>
                    <button
                      onClick={() => setIsDieting(!isDieting)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        isDieting ? "bg-[#5A5A40]" : "bg-[#E5E5E0]"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                        isDieting ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm font-medium text-[#2D2D2D]">
                      <Ban size={16} className="text-red-400" />
                      <span>特殊忌口</span>
                    </div>
                    <input
                      type="text"
                      value={dietaryRestrictions}
                      onChange={(e) => setDietaryRestrictions(e.target.value)}
                      placeholder="如：不吃香菜、海鲜过敏..."
                      className="w-full bg-[#F5F5F0] rounded-xl py-3 px-4 text-sm focus:outline-none focus:ring-1 focus:ring-[#5A5A40]"
                    />
                  </div>
                </div>
              </section>

              <section className="space-y-4">
                <label className="text-sm font-bold uppercase tracking-widest text-[#8E8E80]">用餐时间 ⏰</label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-[#C0C0B0]" size={16} />
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="w-full bg-white border border-[#F0F0E8] rounded-2xl py-3 pl-10 pr-3 text-sm focus:outline-none focus:border-[#5A5A40] appearance-none"
                    />
                  </div>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-[#C0C0B0]" size={16} />
                    <input
                      type="time"
                      value={selectedTime}
                      onChange={(e) => setSelectedTime(e.target.value)}
                      className="w-full bg-white border border-[#F0F0E8] rounded-2xl py-3 pl-10 pr-3 text-sm focus:outline-none focus:border-[#5A5A40] appearance-none"
                    />
                  </div>
                </div>
              </section>

              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="w-full py-5 rounded-full bg-[#5A5A40] text-white font-bold text-lg flex items-center justify-center gap-3 shadow-xl active:scale-95 transition-all"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>正在主厨策划中...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={20} />
                    <span>生成氛围感菜单</span>
                  </>
                )}
              </button>
            </motion.div>
          )}

          {view === 'result' && generatedMenu && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8 pb-12 transition-all duration-500 font-sans tracking-tight"
            >
              <div className="text-center space-y-4">
                <h2 className="font-bold text-3xl serif text-[#2D2D2D]">{generatedMenu.title}</h2>
                <p className="font-medium italic text-lg px-4 transition-all text-[#5A5A40] serif">
                  “{generatedMenu.customizationSummary || "为您精心策划的周末美味时光"}”
                </p>
                <div className="flex items-center justify-center gap-4 text-[#8E8E80] text-xs font-bold uppercase tracking-widest">
                  <div className="flex items-center gap-1.5">
                    <Calendar size={12} />
                    <span>{generatedMenu.mealTime}</span>
                  </div>
                  <div className="w-1 h-1 bg-[#C0C0B0] rounded-full" />
                  <div className="flex items-center gap-1.5">
                    <Users size={12} />
                    <span>{generatedMenu.dinerCount}人份</span>
                  </div>
                </div>
              </div>

              {/* Menu List */}
              <section className="p-6 shadow-sm border transition-all duration-500 relative bg-white rounded-3xl border-[#F0F0E8]">
                <div className="flex items-center justify-center gap-2 border-b pb-4 mb-8 border-[#F0F0E8]">
                  <h3 className="font-bold tracking-widest serif text-lg text-[#2D2D2D]">今日赏味 📜</h3>
                </div>
                
                <div className="space-y-8">
                  {generatedMenu.dishes?.map((dish, idx) => (
                    <div key={idx} className="flex gap-4 items-center transition-all">
                      <div className="shrink-0 overflow-hidden shadow-sm bg-[#F5F5F0] transition-all w-20 h-20 rounded-2xl">
                        {dish.imageUrl ? (
                          <img 
                            src={dish.imageUrl} 
                            alt={dish.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Loader2 className="animate-spin text-[#C0C0B0]" size={20} />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 flex items-center justify-between">
                        <span className="font-bold serif text-base text-[#2D2D2D]">{dish.name}</span>
                        {dish.priority && PRIORITY_LABELS[dish.priority] && (
                          <div className={cn(
                            "text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shadow-sm",
                            PRIORITY_LABELS[dish.priority].bg,
                            PRIORITY_LABELS[dish.priority].color
                          )}>
                            <span>{PRIORITY_LABELS[dish.priority].emoji}</span>
                            <span>{PRIORITY_LABELS[dish.priority].label}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-6 flex justify-center gap-10">
                  <button 
                    onClick={() => alert('已保存到相册 (模拟)')}
                    className="flex flex-col items-center gap-1 text-[#8E8E80] hover:text-[#5A5A40] transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-[#F5F5F0] flex items-center justify-center">
                      <Download size={18} />
                    </div>
                    <span className="text-[10px] font-bold">保存</span>
                  </button>
                  <button 
                    onClick={() => alert('分享链接已复制 (模拟)')}
                    className="flex flex-col items-center gap-1 text-[#8E8E80] hover:text-[#5A5A40] transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-[#F5F5F0] flex items-center justify-center">
                      <Sparkles size={18} />
                    </div>
                    <span className="text-[10px] font-bold">分享</span>
                  </button>
                </div>
              </section>

              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => setView('prep')}
                  className="py-4 rounded-2xl bg-white border border-[#F0F0E8] text-[#5A5A40] font-bold flex flex-col items-center gap-2 shadow-sm active:scale-95 transition-all"
                >
                  <ShoppingBag size={28} />
                  <span className="text-sm">备菜清单</span>
                </button>
                <button
                  onClick={() => setView('recipes')}
                  className="py-4 rounded-2xl bg-white border border-[#F0F0E8] text-[#5A5A40] font-bold flex flex-col items-center gap-2 shadow-sm active:scale-95 transition-all"
                >
                  <ChefHat size={28} />
                  <span className="text-sm">做法参考</span>
                </button>
              </div>

              <button
                onClick={() => setView('home')}
                className="w-full py-4 rounded-full border-2 border-[#5A5A40] text-[#5A5A40] font-bold transition-all active:scale-95"
              >
                回到首页
              </button>
            </motion.div>
          )}

          {view === 'prep' && generatedMenu && (
            <motion.div
              key="prep"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6 pb-12"
            >
              <div className="space-y-1">
                <h2 className="text-2xl font-bold serif">备菜清单 🛒</h2>
                <p className="text-[#8E8E80] text-sm">按菜品分类，确保不遗漏任何美味细节。</p>
              </div>

              <div className="space-y-6">
                {generatedMenu.prepList?.map((dish, dIdx) => (
                  <div key={dIdx} className="bg-white rounded-3xl overflow-hidden border border-[#F0F0E8] shadow-sm">
                    <div className="bg-[#5A5A40] p-4 text-white font-bold serif">
                      {dish.dishName}
                    </div>
                    <div className="p-6 space-y-6">
                      {dish.categories?.map((cat, cIdx) => (
                        <div key={cIdx} className="space-y-3">
                          <h4 className="text-xs font-bold text-[#8E8E80] uppercase tracking-widest flex items-center gap-2">
                            <div className="w-1 h-3 bg-[#5A5A40] rounded-full" />
                            {cat.name}
                          </h4>
                          <div className="space-y-2">
                            {cat.items?.map((item, iIdx) => (
                              <div key={iIdx} className="flex items-center justify-between py-2 border-b border-dotted border-[#F0F0E8] last:border-0">
                                <div className="flex items-center gap-3">
                                  <div className="w-4 h-4 rounded border border-[#C0C0B0]" />
                                  <span className="text-sm text-[#2D2D2D]">{item.name}</span>
                                </div>
                                <span className="text-sm text-[#8E8E80] font-mono">{item.amount}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {view === 'recipes' && generatedMenu && (
            <motion.div
              key="recipes"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6 pb-12"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold serif">做法参考 👨‍🍳</h2>
                  <div className="flex bg-[#F5F5F0] p-1 rounded-xl border border-[#F0F0E8]">
                    {(['beginner', 'intermediate', 'advanced'] as const).map(level => (
                      <button
                        key={level}
                        onClick={() => handleSkillLevelChange(level)}
                        disabled={isRegeneratingRecipes}
                        className={cn(
                          "px-3 py-1 rounded-lg text-[10px] font-bold transition-all",
                          skillLevel === level 
                            ? "bg-[#5A5A40] text-white shadow-sm" 
                            : "text-[#8E8E80]",
                          isRegeneratingRecipes && "opacity-50 cursor-not-allowed"
                        )}
                      >
                        {level === 'beginner' ? '小白' : level === 'intermediate' ? '普通' : '大厨'}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-[#8E8E80] text-sm italic">
                  当前厨艺等级：<span className="text-[#5A5A40] font-bold">{skillLevel === 'beginner' ? '厨房小白' : skillLevel === 'intermediate' ? '普通厨艺' : '大厨级别'}</span>。
                  {skillLevel === 'beginner' && " 我们将为您提供最详尽的操作建议。"}
                  {isRegeneratingRecipes && <span className="ml-2 text-amber-500 animate-pulse">正在为主厨调整方案...</span>}
                </p>
              </div>

              <div className={cn("space-y-10 transition-opacity", isRegeneratingRecipes && "opacity-50")}>
                {generatedMenu.recipes?.map((recipe, rIdx) => (
                  <div key={rIdx} className="space-y-6">
                    <h3 className="text-xl font-bold text-[#2D2D2D] serif border-b-2 border-[#5A5A40] pb-2 inline-block">
                      {recipe.name}
                    </h3>
                    
                    {/* Ingredients - Structured like the screenshot */}
                    <div className="bg-white p-6 rounded-3xl border border-[#F0F0E8] shadow-sm space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-[#2D2D2D]">用料</span>
                        <span className="text-[10px] bg-[#F5F5F0] px-2 py-1 rounded-full text-[#8E8E80]">换算</span>
                      </div>
                      <div className="space-y-3">
                        {recipe.ingredients?.map((ing, iIdx) => (
                          <div key={iIdx} className="flex items-center gap-2 group">
                            <span className="text-sm text-[#2D2D2D] whitespace-nowrap">{ing.name}</span>
                            <div className="flex-1 border-b border-dotted border-[#E5E5E0] mb-1" />
                            <span className="text-sm text-[#8E8E80] font-mono whitespace-nowrap">{ing.amount}</span>
                          </div>
                        ))}
                      </div>
                    </div>
 
                    {/* Steps */}
                    <div className="space-y-8">
                      {recipe.steps?.map((step, sIdx) => (
                        <div key={sIdx} className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-bold text-[#5A5A40]">步骤 {sIdx + 1}</h4>
                            <div className="text-[10px] bg-[#F5F5F0] px-2 py-1 rounded-full text-[#8E8E80]">烹饪模式</div>
                          </div>
                          
                          {step.imageUrl ? (
                            <div className="rounded-3xl overflow-hidden border border-[#F0F0E8] shadow-sm aspect-video">
                              <img 
                                src={step.imageUrl} 
                                alt={`Step ${sIdx + 1}`}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          ) : step.imageSeed ? (
                            <div className="rounded-3xl overflow-hidden border border-[#F0F0E8] shadow-sm aspect-video">
                              <img 
                                src={`https://picsum.photos/seed/${step.imageSeed}/800/450`} 
                                alt={`Step ${sIdx + 1}`}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          ) : null}
                          
                          <p className="text-[#2D2D2D] leading-relaxed text-sm bg-white p-4 rounded-2xl border border-[#F0F0E8]">
                            {step.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Nav (Floating) */}
      {view === 'home' && cravings.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-md px-6">
          <button
            onClick={() => setView('generate')}
            className="w-full py-4 bg-[#5A5A40] text-white rounded-full shadow-2xl flex items-center justify-center gap-2 font-bold animate-bounce-subtle"
          >
            <Sparkles size={18} />
            <span>整合周末菜单</span>
          </button>
        </div>
      )}

      <style>{`
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        .animate-bounce-subtle {
          animation: bounce-subtle 3s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
}
