export interface Craving {
  id: string;
  content: string;
  type: 'text' | 'link' | 'image';
  timestamp: number;
  extractedFood?: string;
  image?: string; // Base64 image data
  priority: 1 | 2 | 3; // 1: 想吃, 2: 很想吃, 3: 馋疯了
}

export interface MenuCustomization {
  dinerCount: number;
  dietaryRestrictions: string;
  isDieting: boolean;
}

export interface MenuPlan {
  title: string;
  atmosphere: string;
  mealTime: string;
  dinerCount?: number;
  customizationSummary?: string;
  nutritionSummary?: string;
  dishes: {
    name: string;
    description: string;
    isFromCravings: boolean;
    priority?: 1 | 2 | 3;
    calories: number;
    imagePrompt: string;
    imageUrl?: string;
  }[];
  totalCalories: number;
  nutrients: {
    protein: number;
    carbs: number;
    sugar: number;
  };
  prepList: {
    dishName: string;
    categories: {
      name: string;
      items: { name: string; amount: string }[];
    }[];
  }[];
  recipes: {
    name: string;
    ingredients: { name: string; amount: string }[];
    steps: {
      description: string;
      imageSeed?: string;
      imageUrl?: string;
    }[];
  }[];
}

export type AtmosphereType = 'CHINESE_FEAST' | 'QUICK_LUNCH' | 'WESTERN_ELEGANT' | 'COZY_BRUNCH' | 'LATE_NIGHT_SNACK';
export type MenuStyle = 'INS' | 'HOTEL' | 'HOME';

export const ATMOSPHERES: Record<AtmosphereType, { label: string; description: string; emoji: string }> = {
  CHINESE_FEAST: {
    label: '丰盛中式晚宴',
    description: '镬气十足，家乡的味道，适合全家共享的团圆感',
    emoji: '🏮'
  },
  QUICK_LUNCH: {
    label: '15分钟快手午餐',
    description: '高效又不失精致，为忙碌的午后注入能量',
    emoji: '⏱️'
  },
  WESTERN_ELEGANT: {
    label: '精致西式晚餐',
    description: '烛光、红酒与仪式感，慢下来的浪漫时光',
    emoji: '🕯️'
  },
  COZY_BRUNCH: {
    label: '慵懒周末早午餐',
    description: '阳光洒进窗台，开启一段慢节奏的悠闲时光',
    emoji: '🥐'
  },
  LATE_NIGHT_SNACK: {
    label: '深夜食堂慰藉',
    description: '治愈疲惫的深夜，一口入魂的温暖',
    emoji: '🌙'
  }
};
