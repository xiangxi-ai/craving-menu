import { GoogleGenAI } from "@google/genai";
import { Craving, MenuPlan, AtmosphereType, ATMOSPHERES, MenuCustomization } from "../types";

export async function extractFoodFromInput(input: string): Promise<string> {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  const ai = new GoogleGenAI({ apiKey });
  const urlRegex = /https?:\/\/[^\s]+/g;
  const urls = input.match(urlRegex);
  const hasUrl = urls && urls.length > 0;

  const prompt = hasUrl 
    ? `你是一个顶级美食专家。用户输入中包含链接：${urls.join(", ")}。
       
       任务：
       1. 优先尝试利用工具（urlContext 或 googleSearch）访问这些链接，抓取网页中的标题、正文或评论，提取核心菜名。
       2. 如果工具访问受限（如小红书反爬），请深度分析用户输入的文字描述部分：“${input}”。通常链接前的文字就是菜名或笔记标题。
       3. 结合两者信息，给出一个或多个具体的菜名。
       
       限制：
       - 只返回菜名，多个菜名用逗号隔开。
       - 不要返回任何解释性文字。
       - 如果实在无法确定，返回"未知"。`
    : `你是一个美食专家。请从以下输入中提取出具体的菜名或食物名称。
       只返回菜名，多个菜名用逗号隔开。如果没有发现食物，返回"未知"。
       输入: ${input}`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: hasUrl ? {
        tools: [{ urlContext: {} }, { googleSearch: {} }]
      } : undefined,
    });
    
    let result = response.text?.trim() || "未知";
    result = result.replace(/[`*]/g, '');
    return result;
  } catch (error) {
    console.error("Error extracting food:", error);
    return "未知";
  }
}

export async function extractFoodFromImage(base64Image: string, textInput?: string): Promise<string> {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  const ai = new GoogleGenAI({ apiKey });
  try {
    const imagePart = {
      inlineData: {
        mimeType: "image/jpeg",
        data: base64Image.split(',')[1] || base64Image,
      },
    };
    
    const textPart = {
      text: `你是一个美食专家。请分析这张图片${textInput ? `以及用户提供的文字描述：“${textInput}”` : ""}，识别出其中的核心菜名或食物名称。
      优先考虑文字描述中的信息，但如果图片中有更明确的食物，请以图片为准。
      只返回菜名，多个菜名用逗号隔开。如果没有发现食物，返回"未知"。"`,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts: [imagePart, textPart] },
    });

    let result = response.text?.trim() || "未知";
    result = result.replace(/[`*]/g, '');
    return result;
  } catch (error) {
    console.error("Error extracting food from image:", error);
    return "未知";
  }
}

export async function generateDishImage(prompt: string): Promise<string> {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  const ai = new GoogleGenAI({ apiKey });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Find a high-quality, direct image URL for the dish: "${prompt}". 
      Search for real food photography. The URL must end with .jpg, .jpeg, .png, or .webp.
      PRIORITIZE images from "Xiaohongshu" (小红书) or "Xiachufang" (下厨房) as they have the best food aesthetics.
      Return ONLY the raw URL string. Do not use markdown.
      If you cannot find a direct image URL, provide a high-quality food image URL from a reliable source like Unsplash or a food blog.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    
    const text = response.text?.trim() || "";
    // More robust regex to catch URLs even if they are inside markdown or text
    const urlMatch = text.match(/https?:\/\/[^\s"'>)]+\.(jpg|jpeg|png|webp|gif)/i) || 
                     text.match(/https?:\/\/[^\s"'>)]+/i);
    
    if (urlMatch) {
      const url = urlMatch[0];
      // Basic validation to ensure it's not just a homepage
      if (url.length > 15 && (url.includes('img') || url.includes('photo') || url.includes('image') || url.match(/\.(jpg|jpeg|png|webp|gif)/i))) {
        return url;
      }
    }

    throw new Error("No suitable image URL found in response");
  } catch (error: any) {
    // Silently fallback to picsum to avoid breaking the UI
    return `https://picsum.photos/seed/${encodeURIComponent(prompt)}/800/800`;
  }
}

export async function generateMenuPlan(
  cravings: Craving[],
  atmosphere: AtmosphereType,
  mealTime: string,
  customization: MenuCustomization,
  skillLevel: 'beginner' | 'intermediate' | 'advanced'
): Promise<MenuPlan> {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  const ai = new GoogleGenAI({ apiKey });
  const atmosphereInfo = ATMOSPHERES[atmosphere];
  const cravingList = cravings.map(c => {
    const priorityLabel = c.priority === 3 ? "极其渴望" : c.priority === 2 ? "非常想吃" : "想吃";
    return `${c.extractedFood || c.content} (${priorityLabel})`;
  }).join(", ");

  const prompt = `你是一个顶级主厨和营养专家。
  用户这周想吃的东西有: ${cravingList}
  
  请为用户策划一顿周末大餐，并严格遵守以下定制化要求：
  - 用餐时间: ${mealTime}
  - 用餐人数: ${customization.dinerCount}人
  - 预期氛围: ${atmosphereInfo.label} (${atmosphereInfo.description})
  - 特殊忌口: ${customization.dietaryRestrictions || "无"}
  - 是否正在减肥: ${customization.isDieting ? "是 (请严格控制热量，增加优质蛋白和蔬菜比例，减少精制碳水)" : "否"}
  - 厨艺水平: ${skillLevel}
  
  **厨艺水平差异化指令 (极其重要)**：
  1. **beginner (厨房小白)**：
     - 做法必须极其详尽，像教小孩一样。
     - 避免专业术语（如“挂糊”、“煸炒”要解释为“裹上淀粉水”、“中小火炒到变色”）。
     - 强调火候（大火/中火/小火）和具体时间（分钟）。
     - 提供防错提示（如“小心溅油”、“不要盖盖子”）。
  2. **intermediate (普通厨艺)**：
     - 使用标准烹饪术语。
     - 侧重调味平衡和火候控制。
     - 步骤简洁明了，默认用户具备基础刀工。
  3. **advanced (大厨级别)**：
     - 引入专业技法（如“美拉德反应”、“低温慢煮”、“浓缩酱汁”）。
     - 侧重食材处理的极致细节 and 摆盘艺术。
     - 鼓励尝试复杂的风味组合。

  要求：
  1. 优先使用用户想吃的菜品。
  2. 根据人数 (${customization.dinerCount}人) 调整分量。
  3. 润色菜名，使其更具氛围感。
  4. 为每道菜估算大致的热量（卡路里）。
  5. 计算整套菜单的总热量 (totalCalories)。
  6. 提供核心营养素比例 (nutrients): 蛋白质 (protein), 碳水化合物 (carbs), 糖分 (sugar) 的百分比。
  7. 为整套菜单提供一个整体的营养建议。
  8. **定制化优化说明 (customizationSummary)** 必须精简且富有情感，控制在 30 字以内。
  9. 为每道菜提供一个简短的描述，用于搜索真实的菜品图片（imagePrompt）。
  10. **必须完整提供** 备菜清单 (prepList) 和每道菜的差异化做法 (recipes)，不得为空。
  
  请以 JSON 格式返回，结构如下：
  {
    "title": "菜单标题",
    "atmosphere": "氛围描述",
    "mealTime": "用餐时间",
    "dinerCount": 2,
    "customizationSummary": "精简的情感化描述",
    "nutritionSummary": "营养建议",
    "totalCalories": 1200,
    "nutrients": {
      "protein": 30,
      "carbs": 50,
      "sugar": 20
    },
    "dishes": [
      {
        "name": "菜名", 
        "description": "氛围感描述", 
        "isFromCravings": true, 
        "priority": 3,
        "calories": 450,
        "imagePrompt": "a high-quality food photography of [dish name]"
      }
    ],
    "prepList": [
      {
        "dishName": "菜名",
        "categories": [
          { "name": "主料/辅料/调料", "items": [{ "name": "食材", "amount": "用量" }] }
        ]
      }
    ],
    "recipes": [
      {
        "name": "菜名",
        "ingredients": [{ "name": "食材", "amount": "用量" }],
        "steps": [{ "description": "详细步骤描述", "imageSeed": "关键词" }]
      }
    ]
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const result = JSON.parse(response.text || "{}");
    return result as MenuPlan;
  } catch (error) {
    console.error("Error generating menu:", error);
    throw error;
  }
}

export async function regenerateRecipes(
  menu: MenuPlan,
  skillLevel: 'beginner' | 'intermediate' | 'advanced'
): Promise<MenuPlan['recipes']> {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  const ai = new GoogleGenAI({ apiKey });
  const dishNames = menu.dishes.map(d => d.name).join(", ");
  const prompt = `你是一个顶级主厨。
  当前的菜单包含以下菜品：${dishNames}
  
  请为这些菜品重新编写烹饪步骤，目标厨艺水平是：${skillLevel}。
  
  **厨艺水平差异化指令 (极其重要)**：
  1. **beginner (厨房小白)**：
     - 做法必须极其详尽，像教小孩一样。
     - 避免专业术语。
     - 强调火候和具体时间。
     - 提供防错提示。
  2. **intermediate (普通厨艺)**：
     - 使用标准烹饪术语。
     - 侧重调味平衡和火候控制。
  3. **advanced (大厨级别)**：
     - 引入专业技法（如“美拉德反应”、“低温慢煮”、“浓缩酱汁”）。
     - 侧重食材处理的极致细节和摆盘艺术。

  请以 JSON 格式返回，结构如下：
  {
    "recipes": [
      {
        "name": "菜名",
        "ingredients": [{"name": "食材名", "amount": "用量"}],
        "steps": [{"description": "步骤描述", "imageSeed": "关键词"}]
      }
    ]
  }`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
    },
  });

  try {
    const data = JSON.parse(response.text);
    return data.recipes;
  } catch (e) {
    console.error("Failed to parse regenerated recipes", e);
    return menu.recipes;
  }
}
